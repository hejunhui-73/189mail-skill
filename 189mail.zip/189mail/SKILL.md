---
name: 189mail
description: 使用中国电信 189 邮箱处理邮件任务；当用户要求查看 189 邮箱、搜索/阅读邮件、整理未读邮件、检查邮箱设置、通过 189 邮箱拟稿或发送邮件时触发。优先使用官方 IMAP/SMTP；需要网页操作时使用官方 Webmail 入口并让用户完成人机验证。
homepage: https://webmail30.189.cn/w2/index.html
metadata:
  short-description: 处理中国电信 189 邮箱
---

# 189 邮箱

## 适用场景

- 查看收件箱、未读邮件、最近邮件或按关键词搜索邮件。
- 阅读指定邮件并摘要、提取时间/待办/附件名称等信息。
- 起草 189 邮箱邮件；发送邮件前必须向用户确认。
- 帮用户打开或检查 189 Webmail 页面、客户端配置、IMAP/SMTP 设置。

## 安全边界

- 不保存、回显或记录邮箱密码、短信验证码、二维码、Cookie、附件正文中的敏感信息。
- 不尝试绕过验证码、短信验证、二维码登录、风控或账号锁定。
- “免密码”模式仅通过网页登录：由用户自行完成登录/验证码/短信/扫码，OpenClaw 只操作当前已登录页面；默认不保存浏览器状态、不导出 Cookie。
- 发邮件、删除邮件、移动邮件、修改规则、下载附件、公开转发内容前，必须先说明操作对象并获得用户明确同意。
- 邮件正文只输出与用户任务相关的最小必要内容；默认优先输出摘要和元信息。

## 官方入口与服务器

- Webmail: `https://webmail30.189.cn/w2/index.html`
- 帮助中心: `https://mail.189.cn/webmail/help.html`
- IMAP: `imap.189.cn`
- POP3: `pop.189.cn`
- SMTP: `smtp.189.cn`

官方帮助说明 189 邮箱支持 IMAP/POP3/SMTP 客户端配置；发信服务器需要身份验证。若网页登录失败或遇到验证码，改由用户在浏览器中手动登录。

## 推荐工作流

1. 判断用户要做的是读取、摘要、搜索、拟稿、发送还是网页排障。
2. 如果用户要求“免密码/网页登录/在 OpenClaw 操作 189 邮箱”，优先使用 `scripts/webmail_browser.py` 打开 Webmail；用户自行完成登录验证后，再用 `snapshot` 读取已登录页面并继续操作。
3. 邮件读取类任务也可使用 `scripts/imap_mail.py`，默认 `--protocol auto`：先用 IMAP，若 189 服务器登录超时/异常则自动兜底 POP3 读取邮件元信息。
4. 查询当天邮件可用 `list --today`；POP3 兜底只能稳定读取列表/元信息，读取完整正文仍优先用 IMAP 或网页端。
5. 网页类任务打开 Webmail 入口；如出现登录验证，让用户自己完成验证，再继续读取页面可见信息。
4. 发送类任务先生成草稿内容并让用户确认；确认后再用 SMTP 发送，或指导用户在 Webmail 中手动发送。

## 凭据约定

优先从环境变量读取。`MAIL189_PASSWORD` 应优先使用 189 邮箱的“客户端专用密码/授权码”，不要使用网页登录密码：

```bash
export MAIL189_EMAIL="手机号@189.cn"
export MAIL189_PASSWORD="***客户端专用密码/授权码***"
```

可选覆盖：

```bash
export MAIL189_IMAP_HOST="imap.189.cn"
export MAIL189_SMTP_HOST="smtp.189.cn"
export MAIL189_IMAP_PORT="993"
export MAIL189_SMTP_PORT="465"
```

如果用户没有设置环境变量，可以请用户临时输入客户端专用密码/授权码；不要把密码、授权码写入仓库文件、日志或记忆文件。

## 本地脚本

IMAP/POP3/SMTP 脚本使用 Python 标准库，无额外依赖：

```bash
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/imap_mail.py list --limit 10
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/imap_mail.py list --today --limit 10
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/imap_mail.py list --protocol pop3 --today --limit 10
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/imap_mail.py search --query "会议" --limit 10
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/imap_mail.py read --uid 12345
```

网页登录免密码模式（需要 `agent-browser`）：

```bash
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/webmail_browser.py open --system-chrome
# 推荐：打开系统 Chrome 专用窗口并启用 CDP；用户在该窗口自行完成登录/验证码/短信/扫码
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/webmail_browser.py wait-login --cdp
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/webmail_browser.py snapshot --cdp --compact
```

说明：该模式不需要向 OpenClaw 提供密码，也不保存 Cookie；每次需要操作邮箱时重新网页登录。

发送邮件必须带确认参数：

```bash
python3 /Users/hejunhui/.openclaw/workspace/skills/189mail/scripts/imap_mail.py send \
  --to "name@example.com" \
  --subject "主题" \
  --body "正文" \
  --yes-i-understand-send-email
```

## 输出原则

- 列表输出：`uid`、已读状态、发件人、时间、主题。
- 阅读输出：先给摘要；只有用户明确需要时再展示完整正文。
- 搜索输出：说明搜索范围和命中数量。
- 错误输出：区分凭据缺失、登录失败、服务器不可达、验证/风控、参数错误。
