#!/usr/bin/env python3
"""Open and inspect 189 Webmail with agent-browser.

This helper never asks for or stores passwords/cookies. The user completes login,
CAPTCHA, SMS, QR verification, etc. in the opened browser session. OpenClaw can
then inspect and operate the already-authenticated visible page via agent-browser.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import date, datetime, timedelta

WEBMAIL_URL = "https://webmail30.189.cn/w2/index.html"
DEFAULT_SESSION = "189mail"
DEFAULT_CDP_PORT = "9222"
DEFAULT_CDP_PROFILE = os.path.expanduser("~/.openclaw/browser-profiles/189mail-cdp")


LIST_JS = r"""
(() => {
  const out = [];
  let group = '';
  const wrap = document.querySelector('.mail-wrap') || document.body;
  for (const el of wrap.querySelectorAll('*')) {
    const text = (el.innerText || '').trim();
    if (/^(今天|昨天|星期|上周|更早)/.test(text) && text.length < 30) group = text;
    if (el.classList && el.classList.contains('mail-list-bd-item')) {
      out.push({
        group,
        unread: el.className.includes('ml-unread'),
        from: (el.querySelector('.j-sender')?.innerText || '').trim(),
        title: (el.querySelector('.ml-con-title')?.innerText || '').trim(),
        abstract: (el.querySelector('.j-ml-abstract')?.innerText || '').trim(),
        dateText: (el.querySelector('.ml-time')?.innerText || '').trim()
      });
    }
  }
  return out;
})()
"""


def run_agent_browser(args: list[str], *, headed: bool = False, cdp: str | None = None) -> int:
    if not shutil.which("agent-browser"):
        print(
            "agent-browser is not installed or not on PATH. Cannot automate Webmail page.",
            file=sys.stderr,
        )
        return 127
    cmd = ["agent-browser", "--session", DEFAULT_SESSION]
    if cdp:
        cmd.extend(["--cdp", cdp])
    if headed:
        cmd.append("--headed")
    cmd.extend(args)
    return subprocess.call(cmd)


def capture_agent_browser(args: list[str], *, cdp: str | None = None) -> dict:
    if not shutil.which("agent-browser"):
        raise RuntimeError("agent-browser is not installed or not on PATH")
    cmd = ["agent-browser", "--session", DEFAULT_SESSION]
    if cdp:
        cmd.extend(["--cdp", cdp])
    cmd.extend(args)
    proc = subprocess.run(cmd, text=True, capture_output=True, check=False)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or f"agent-browser exited {proc.returncode}")
    return json.loads(proc.stdout)


def open_webmail(args: argparse.Namespace) -> int:
    if args.system_chrome:
        os.makedirs(args.profile, exist_ok=True)
        chrome = "/Applications/Google Chrome.app"
        if not os.path.exists(chrome):
            print("Google Chrome not found at /Applications/Google Chrome.app", file=sys.stderr)
            return 127
        return subprocess.call(
            [
                "open",
                "-na",
                "Google Chrome",
                "--args",
                f"--remote-debugging-port={args.cdp_port}",
                f"--user-data-dir={args.profile}",
                WEBMAIL_URL,
            ]
        )
    return run_agent_browser(["open", WEBMAIL_URL], headed=not args.headless)


def snapshot(args: argparse.Namespace) -> int:
    cmd = ["snapshot", "-i", "--json"]
    if args.compact:
        cmd.append("-c")
    if args.depth:
        cmd.extend(["-d", str(args.depth)])
    return run_agent_browser(cmd, cdp=args.cdp_port if args.cdp else None)


def wait_login(args: argparse.Namespace) -> int:
    # Wait for common post-login mailbox text. If the page wording changes, callers can
    # still use snapshot to inspect the current page and continue manually.
    wait_texts = ["收件箱", "写信", "邮件"]
    for text in wait_texts:
        code = run_agent_browser(["wait", "--text", text], cdp=args.cdp_port if args.cdp else None)
        if code == 0:
            print(json.dumps({"status": "login_visible", "matched_text": text}, ensure_ascii=False))
            return 0
    print(json.dumps({"status": "not_detected", "hint": "login may still be pending; run snapshot"}, ensure_ascii=False))
    return 1


def normalize_date(item: dict, today: date) -> str | None:
    date_text = (item.get("dateText") or "").strip()
    group = (item.get("group") or "").strip()
    if date_text.startswith("20") and "年" in date_text:
        try:
            return datetime.strptime(date_text, "%Y年%m月%d日").date().isoformat()
        except ValueError:
            return None
    if "月" in date_text and "日" in date_text:
        try:
            parsed = datetime.strptime(f"{today.year}年{date_text}", "%Y年%m月%d日").date()
            return parsed.isoformat()
        except ValueError:
            return None
    if group.startswith("今天") or ":" in date_text:
        return today.isoformat()
    if group.startswith("昨天"):
        return (today - timedelta(days=1)).isoformat()
    return None


def list_messages(args: argparse.Namespace) -> int:
    cdp = args.cdp_port if args.cdp else None
    payload = capture_agent_browser(["eval", LIST_JS, "--json"], cdp=cdp)
    items = payload.get("data", {}).get("result", [])
    today = date.today()
    start = today - timedelta(days=args.days - 1) if args.days else None
    results = []
    for item in items:
        iso = normalize_date(item, today)
        item["date"] = iso
        if args.today and iso != today.isoformat():
            continue
        if start and (iso is None or iso < start.isoformat() or iso > today.isoformat()):
            continue
        if args.unread and not item.get("unread"):
            continue
        if args.query:
            haystack = "\n".join(str(item.get(k, "")) for k in ("from", "title", "abstract")).casefold()
            if args.query.casefold() not in haystack:
                continue
        results.append(item)
        if args.limit and len(results) >= args.limit:
            break
    print(json.dumps({"count": len(results), "items": results}, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="189 Webmail browser helper")
    sub = parser.add_subparsers(dest="command", required=True)

    open_cmd = sub.add_parser("open", help="Open 189 Webmail in a visible browser session")
    open_cmd.add_argument("--headless", action="store_true", help="Do not show the browser window")
    open_cmd.add_argument("--system-chrome", action="store_true", help="Open visible Google Chrome with CDP so agent-browser can attach")
    open_cmd.add_argument("--cdp-port", default=DEFAULT_CDP_PORT)
    open_cmd.add_argument("--profile", default=DEFAULT_CDP_PROFILE)
    open_cmd.set_defaults(func=open_webmail)

    wait_cmd = sub.add_parser("wait-login", help="Wait until a mailbox-like page is visible")
    wait_cmd.add_argument("--cdp", action="store_true", help="Attach to system Chrome opened with --system-chrome")
    wait_cmd.add_argument("--cdp-port", default=DEFAULT_CDP_PORT)
    wait_cmd.set_defaults(func=wait_login)

    snap_cmd = sub.add_parser("snapshot", help="Dump interactive page snapshot as JSON")
    snap_cmd.add_argument("--compact", action="store_true")
    snap_cmd.add_argument("--depth", type=int, default=6)
    snap_cmd.add_argument("--cdp", action="store_true", help="Attach to system Chrome opened with --system-chrome")
    snap_cmd.add_argument("--cdp-port", default=DEFAULT_CDP_PORT)
    snap_cmd.set_defaults(func=snapshot)

    list_cmd = sub.add_parser("list", help="List visible Webmail messages with simple filters")
    list_cmd.add_argument("--cdp", action="store_true", help="Attach to system Chrome opened with --system-chrome")
    list_cmd.add_argument("--cdp-port", default=DEFAULT_CDP_PORT)
    list_cmd.add_argument("--today", action="store_true", help="Only messages dated today")
    list_cmd.add_argument("--days", type=int, help="Only messages in the last N days, including today")
    list_cmd.add_argument("--unread", action="store_true", help="Only unread messages")
    list_cmd.add_argument("--query", help="Case-insensitive keyword match in sender/title/abstract")
    list_cmd.add_argument("--limit", type=int, default=0)
    list_cmd.set_defaults(func=list_messages)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
