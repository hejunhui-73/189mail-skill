#!/usr/bin/env python3
"""Small IMAP/SMTP helper for China Telecom 189 Mail."""

from __future__ import annotations

import argparse
import email
import imaplib
import json
import os
import poplib
import smtplib
import socket
import ssl
import sys
from email.header import decode_header
from email.message import EmailMessage, Message
from email.utils import parsedate_to_datetime
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo


def env(name: str, default: str | None = None) -> str:
    value = os.environ.get(name, default)
    if value is None or value == "":
        raise SystemExit(f"Missing required environment variable: {name}")
    return value


def decode_mime(value: str | None) -> str:
    if not value:
        return ""
    parts: list[str] = []
    for chunk, charset in decode_header(value):
        if isinstance(chunk, bytes):
            parts.append(chunk.decode(charset or "utf-8", errors="replace"))
        else:
            parts.append(chunk)
    return "".join(parts)


def message_body(msg: Message) -> str:
    if msg.is_multipart():
        fallback = ""
        for part in msg.walk():
            content_type = part.get_content_type()
            disposition = (part.get("Content-Disposition") or "").lower()
            if "attachment" in disposition:
                continue
            payload = part.get_payload(decode=True)
            if not payload:
                continue
            charset = part.get_content_charset() or "utf-8"
            text = payload.decode(charset, errors="replace")
            if content_type == "text/plain":
                return text.strip()
            if content_type == "text/html" and not fallback:
                fallback = text
        return fallback.strip()

    payload = msg.get_payload(decode=True)
    if payload is None:
        raw = msg.get_payload()
        return raw.strip() if isinstance(raw, str) else ""
    charset = msg.get_content_charset() or "utf-8"
    return payload.decode(charset, errors="replace").strip()


def connect_imap() -> imaplib.IMAP4_SSL:
    host = os.environ.get("MAIL189_IMAP_HOST", "imap.189.cn")
    port = int(os.environ.get("MAIL189_IMAP_PORT", "993"))
    timeout = int(os.environ.get("MAIL189_TIMEOUT", "20"))
    user = env("MAIL189_EMAIL")
    password = env("MAIL189_PASSWORD")
    socket.setdefaulttimeout(timeout)
    conn = imaplib.IMAP4_SSL(host, port, timeout=timeout)
    conn.login(user, password)
    return conn


def connect_pop3() -> poplib.POP3_SSL:
    host = os.environ.get("MAIL189_POP3_HOST", "pop.189.cn")
    port = int(os.environ.get("MAIL189_POP3_PORT", "995"))
    timeout = int(os.environ.get("MAIL189_TIMEOUT", "20"))
    user = env("MAIL189_EMAIL")
    password = env("MAIL189_PASSWORD")
    socket.setdefaulttimeout(timeout)
    conn = poplib.POP3_SSL(host, port, timeout=timeout)
    conn.user(user)
    conn.pass_(password)
    return conn


def parse_message_date(msg: Message) -> datetime | None:
    raw = msg.get("Date")
    if not raw:
        return None
    try:
        return parsedate_to_datetime(raw)
    except Exception:
        return None


def is_today(msg: Message) -> bool:
    dt = parse_message_date(msg)
    if dt is None:
        return False
    tz = ZoneInfo(os.environ.get("MAIL189_TZ", "Asia/Shanghai"))
    if dt.tzinfo is None:
        local = dt.replace(tzinfo=tz)
    else:
        local = dt.astimezone(tz)
    return local.date() == datetime.now(tz).date()


def pop_meta(conn: poplib.POP3_SSL, index: int) -> dict[str, Any]:
    _, lines, _ = conn.top(index, 0)
    msg = email.message_from_bytes(b"\r\n".join(lines) + b"\r\n\r\n")
    dt = parse_message_date(msg)
    try:
        date = dt.isoformat() if dt else (msg.get("Date") or "")
    except Exception:
        date = msg.get("Date") or ""
    return {
        "protocol": "POP3",
        "pop_index": index,
        "from": decode_mime(msg.get("From")),
        "date": date,
        "subject": decode_mime(msg.get("Subject")),
    }


def pop_list_messages(args: argparse.Namespace) -> None:
    conn = connect_pop3()
    try:
        count, _ = conn.stat()
        results: list[dict[str, Any]] = []
        scan_limit = min(count, args.scan_limit)
        for index in range(count, count - scan_limit, -1):
            meta = pop_meta(conn, index)
            if args.today:
                _, lines, _ = conn.top(index, 0)
                msg = email.message_from_bytes(b"\r\n".join(lines) + b"\r\n\r\n")
                if not is_today(msg):
                    if results:
                        break
                    continue
            results.append(meta)
            if len(results) >= args.limit:
                break
        print(json.dumps(results, ensure_ascii=False, indent=2))
    finally:
        conn.quit()


def select_mailbox(conn: imaplib.IMAP4_SSL, mailbox: str) -> None:
    status, _ = conn.select(mailbox, readonly=True)
    if status != "OK":
        raise SystemExit(f"Cannot select mailbox: {mailbox}")


def fetch_message(conn: imaplib.IMAP4_SSL, uid: str, body: bool = True) -> Message:
    query = "(RFC822)" if body else "(BODY.PEEK[HEADER])"
    status, data = conn.uid("fetch", uid, query)
    if status != "OK" or not data or not isinstance(data[0], tuple):
        raise SystemExit(f"Cannot fetch message uid={uid}")
    return email.message_from_bytes(data[0][1])


def mail_meta(conn: imaplib.IMAP4_SSL, uid: str) -> dict[str, Any]:
    msg = fetch_message(conn, uid, body=False)
    date_raw = msg.get("Date")
    try:
        date = parsedate_to_datetime(date_raw).isoformat() if date_raw else ""
    except Exception:
        date = date_raw or ""
    status, flag_data = conn.uid("fetch", uid, "(FLAGS)")
    flags = flag_data[0].decode(errors="replace") if status == "OK" and flag_data else ""
    return {
        "uid": uid,
        "unread": "\\Seen" not in flags,
        "from": decode_mime(msg.get("From")),
        "date": date,
        "subject": decode_mime(msg.get("Subject")),
    }


def list_messages(args: argparse.Namespace) -> None:
    if args.protocol == "pop3":
        pop_list_messages(args)
        return
    conn = None
    try:
        conn = connect_imap()
        select_mailbox(conn, args.mailbox)
        criterion = "UNSEEN" if args.unread else "ALL"
        status, data = conn.uid("search", None, criterion)
        if status != "OK":
            raise SystemExit("IMAP search failed")
        uids = data[0].decode().split()
        selected = list(reversed(uids))[: args.limit if not args.today else args.scan_limit]
        if args.today:
            metas = []
            for uid in selected:
                msg = fetch_message(conn, uid, body=False)
                if is_today(msg):
                    metas.append(mail_meta(conn, uid))
                elif metas:
                    break
                if len(metas) >= args.limit:
                    break
            print(json.dumps(metas, ensure_ascii=False, indent=2))
            return
        print(json.dumps([mail_meta(conn, uid) for uid in selected], ensure_ascii=False, indent=2))
    except (TimeoutError, OSError, imaplib.IMAP4.error) as exc:
        if args.protocol == "auto":
            print(f"IMAP unavailable, falling back to POP3: {exc}", file=sys.stderr)
            pop_list_messages(args)
            return
        raise
    finally:
        if conn is not None:
            try:
                conn.logout()
            except Exception:
                pass


def search_messages(args: argparse.Namespace) -> None:
    conn = connect_imap()
    try:
        select_mailbox(conn, args.mailbox)
        status, data = conn.uid("search", None, "ALL")
        if status != "OK":
            raise SystemExit("IMAP search failed")
        uids = list(reversed(data[0].decode().split()))[: args.scan_limit]
        results: list[dict[str, Any]] = []
        needle = args.query.casefold()
        for uid in uids:
            msg = fetch_message(conn, uid, body=True)
            meta = mail_meta(conn, uid)
            haystack = "\n".join(
                [
                    meta.get("from", ""),
                    meta.get("subject", ""),
                    message_body(msg),
                ]
            ).casefold()
            if needle in haystack:
                results.append(meta)
            if len(results) >= args.limit:
                break
        print(json.dumps(results, ensure_ascii=False, indent=2))
    finally:
        conn.logout()


def read_message(args: argparse.Namespace) -> None:
    conn = connect_imap()
    try:
        select_mailbox(conn, args.mailbox)
        msg = fetch_message(conn, args.uid, body=True)
        result = mail_meta(conn, args.uid)
        result["body"] = message_body(msg)
        result["attachments"] = [
            decode_mime(part.get_filename())
            for part in msg.walk()
            if part.get_filename()
        ]
        print(json.dumps(result, ensure_ascii=False, indent=2))
    finally:
        conn.logout()


def send_message(args: argparse.Namespace) -> None:
    if not args.yes_i_understand_send_email:
        raise SystemExit("Refusing to send without --yes-i-understand-send-email")

    user = env("MAIL189_EMAIL")
    password = env("MAIL189_PASSWORD")
    host = os.environ.get("MAIL189_SMTP_HOST", "smtp.189.cn")
    port = int(os.environ.get("MAIL189_SMTP_PORT", "465"))

    msg = EmailMessage()
    msg["From"] = user
    msg["To"] = args.to
    msg["Subject"] = args.subject
    msg.set_content(args.body)

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(host, port, context=context) as smtp:
        smtp.login(user, password)
        smtp.send_message(msg)

    print(json.dumps({"status": "sent", "to": args.to, "subject": args.subject}, ensure_ascii=False))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="189 Mail IMAP/SMTP helper")
    sub = parser.add_subparsers(dest="command", required=True)

    list_cmd = sub.add_parser("list", help="List recent messages")
    list_cmd.add_argument("--mailbox", default="INBOX")
    list_cmd.add_argument("--limit", type=int, default=10)
    list_cmd.add_argument("--scan-limit", type=int, default=200, help="How many newest messages to scan when filtering")
    list_cmd.add_argument("--unread", action="store_true")
    list_cmd.add_argument("--today", action="store_true", help="Only list messages dated today in MAIL189_TZ/Asia-Shanghai")
    list_cmd.add_argument("--protocol", choices=["auto", "imap", "pop3"], default="auto", help="Use IMAP, POP3, or IMAP with POP3 fallback")
    list_cmd.set_defaults(func=list_messages)

    search_cmd = sub.add_parser("search", help="Search messages by text")
    search_cmd.add_argument("--mailbox", default="INBOX")
    search_cmd.add_argument("--query", required=True)
    search_cmd.add_argument("--limit", type=int, default=10)
    search_cmd.add_argument("--scan-limit", type=int, default=200)
    search_cmd.set_defaults(func=search_messages)

    read_cmd = sub.add_parser("read", help="Read one message by UID")
    read_cmd.add_argument("--mailbox", default="INBOX")
    read_cmd.add_argument("--uid", required=True)
    read_cmd.set_defaults(func=read_message)

    send_cmd = sub.add_parser("send", help="Send an email via SMTP")
    send_cmd.add_argument("--to", required=True)
    send_cmd.add_argument("--subject", required=True)
    send_cmd.add_argument("--body", required=True)
    send_cmd.add_argument("--yes-i-understand-send-email", action="store_true")
    send_cmd.set_defaults(func=send_message)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        args.func(args)
        return 0
    except imaplib.IMAP4.error as exc:
        print(f"IMAP error: {exc}", file=sys.stderr)
        return 2
    except smtplib.SMTPException as exc:
        print(f"SMTP error: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
